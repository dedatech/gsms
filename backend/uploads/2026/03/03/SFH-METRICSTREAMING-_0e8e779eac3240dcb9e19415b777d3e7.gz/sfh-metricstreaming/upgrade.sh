#!/bin/bash
source ~/.bash_profile
script_dir=$(cd "$(dirname "$0")"; pwd)
cd $script_dir

#项目名称
PRODUCT_NAME=sfh
#模块名称
MODULE_NAME=metricstreaming

#安装目录
if [ -z $UYUN_ROOT_DIR ]; then
    UYUN_ROOT_DIR=/opt
fi
# 安装路径
INSTALL_DIR=$UYUN_ROOT_DIR/uyun/$PRODUCT_NAME/$MODULE_NAME

# 替换jar包
\cp -rfp ./* $INSTALL_DIR
rm -rf $INSTALL_DIR/upgrade.sh
echo "补丁安装成功"
